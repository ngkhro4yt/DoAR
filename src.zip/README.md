# Đo AR – app đo bằng camera cho Android

Dùng cho Samsung Galaxy Note 20 / Note 20 Ultra, Android 13. Chạy trên nền ARCore của Google.

## Chức năng
1. Đo khoảng cách 2 điểm
2. Đo nhiều đoạn liên tiếp, cộng tổng chiều dài
3. Đo diện tích đa giác, kèm chu vi
4. Đo chiều cao theo phương đứng
5. Thước thủy: dựng đứng đo nghiêng cạnh, đặt nằm đo 2 phương
6. Chụp màn hình kèm số đo, lưu vào Pictures/DoAR
7. Danh sách số đo, ghi chú, xuất Excel .xlsx vào Download/DoAR

Số đo bằng AR chỉ để tham khảo, không dùng nghiệm thu khối lượng.

## Đóng gói APK bằng GitHub, không cần cài phần mềm
1. Tạo tài khoản miễn phí tại https://github.com
2. Bấm **New repository**, đặt tên `DoAR`, chọn **Public**, bấm **Create repository**.
3. Bấm **uploading an existing file**, kéo thả **toàn bộ nội dung** thư mục `DoAR` (không phải bản thân thư mục), bấm **Commit changes**.
4. Kiểm tra có thư mục `.github/workflows/build.yml` trên GitHub chưa. Nếu không thấy, do máy tính ẩn thư mục bắt đầu bằng dấu chấm: bấm **Add file → Create new file**, gõ tên `.github/workflows/build.yml`, dán nội dung file `build.yml`, bấm **Commit changes**.
5. Mở tab **Actions**, chờ khoảng 5–8 phút đến khi có dấu tích xanh.
6. Trên điện thoại, mở trang repository, vào mục **Releases**, tải file `DoAR.apk`, mở để cài. Máy hỏi thì cho phép **cài từ nguồn không xác định**.
7. Lần đầu mở app, máy có thể yêu cầu cài **Google Play Services for AR** từ CH Play: bấm đồng ý.

Mỗi lần build tạo chữ ký mới; muốn cài bản mới thì gỡ bản cũ trước. Danh sách số đo sẽ mất khi gỡ, nên xuất Excel trước.

## Cách dùng
- Lia máy chậm 2–5 giây cho tâm ngắm chuyển màu xanh lá. Vàng: bề mặt chưa chắc chắn. Đỏ hoặc xám: chưa đo được.
- Ngắm tâm vào điểm cần đo, bấm **+**.
- **Diện tích**: bấm + lần lượt các góc, quay về điểm đầu (vòng xanh hiện ra) hoặc bấm **Xong**.
- **Chiều cao**: điểm 1 là chân vật trên sàn, sau đó nâng máy ngắm đỉnh rồi bấm +.
- Mỗi số đo hoàn thành tự lưu vào **Danh sách**.
- Mẹo tăng độ chính xác: đủ sáng, bề mặt có chi tiết, đứng cách 0,5–3 m, đo vuông góc.
