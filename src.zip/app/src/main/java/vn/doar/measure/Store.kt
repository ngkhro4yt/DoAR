package vn.doar.measure

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Record(
    val time: Long,
    val type: String,
    val value: Double,   // m hoặc m²
    val unit: String,    // "m" hoặc "m²"
    val detail: String,
    var note: String = ""
)

/** Lưu danh sách số đo trong bộ nhớ máy (SharedPreferences, dạng JSON). */
object Store {
    private const val PREF = "doar"
    private const val KEY = "records"

    fun load(ctx: Context): MutableList<Record> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val out = ArrayList<Record>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Record(
                        o.getLong("t"), o.getString("type"), o.getDouble("v"),
                        o.getString("u"), o.optString("d", ""), o.optString("n", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun save(ctx: Context, list: List<Record>) {
        val arr = JSONArray()
        for (r in list) {
            arr.put(
                JSONObject()
                    .put("t", r.time).put("type", r.type).put("v", r.value)
                    .put("u", r.unit).put("d", r.detail).put("n", r.note)
            )
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun add(ctx: Context, r: Record) {
        val l = load(ctx)
        l.add(r)
        save(ctx, l)
    }

    fun unit(ctx: Context): LenUnit {
        val name = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("unit", LenUnit.CM.name)
        return runCatching { LenUnit.valueOf(name ?: "CM") }.getOrDefault(LenUnit.CM)
    }

    fun setUnit(ctx: Context, u: LenUnit) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("unit", u.name).apply()
    }
}
