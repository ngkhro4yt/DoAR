package vn.doar.measure

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Danh sách số đo đã lưu + xuất Excel (chức năng 7). */
class HistoryActivity : Activity() {
    private lateinit var list: ListView
    private lateinit var txtInfo: TextView
    private var recs: MutableList<Record> = mutableListOf()
    private val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        list = findViewById(R.id.list)
        txtInfo = findViewById(R.id.txtInfo)

        findViewById<Button>(R.id.btnExport).setOnClickListener { export() }
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnClearAll).setOnClickListener {
            if (recs.isEmpty()) return@setOnClickListener
            AlertDialog.Builder(this)
                .setTitle("Xóa toàn bộ danh sách?")
                .setMessage("Nên xuất Excel trước khi xóa.")
                .setPositiveButton("Xóa") { _, _ -> Store.save(this, emptyList()); refresh() }
                .setNegativeButton("Hủy", null)
                .show()
        }
        list.setOnItemClickListener { _, _, pos, _ -> editNote(pos) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this)
                .setTitle("Xóa số đo #${pos + 1}?")
                .setPositiveButton("Xóa") { _, _ ->
                    recs.removeAt(pos); Store.save(this, recs); refresh()
                }
                .setNegativeButton("Hủy", null)
                .show()
            true
        }
        refresh()
    }

    private fun refresh() {
        recs = Store.load(this)
        val unit = Store.unit(this)
        val items = recs.mapIndexed { i, r ->
            val sb = StringBuilder()
            sb.append("${i + 1}. ${r.type}: ${Geo.fmtRecord(r, unit)}\n")
            sb.append(df.format(Date(r.time)))
            if (r.detail.isNotBlank()) sb.append("\n").append(r.detail)
            if (r.note.isNotBlank()) sb.append("\nGhi chú: ").append(r.note)
            sb.toString()
        }
        list.adapter = ArrayAdapter(this, R.layout.item_record, items)
        txtInfo.text = if (recs.isEmpty()) "Chưa có số đo nào."
        else "${recs.size} số đo. Chạm để ghi chú, chạm giữ để xóa."
    }

    private fun editNote(pos: Int) {
        val r = recs[pos]
        val et = EditText(this).apply { setText(r.note); hint = "Ví dụ: Phòng khách tầng 3, trục A-B" }
        AlertDialog.Builder(this)
            .setTitle("Ghi chú cho số đo #${pos + 1}")
            .setView(et)
            .setPositiveButton("Lưu") { _, _ ->
                r.note = et.text.toString().trim()
                Store.save(this, recs)
                refresh()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun export() {
        if (recs.isEmpty()) {
            Toast.makeText(this, "Chưa có số đo để xuất", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val name = "DoAR_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".xlsx"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, Xlsx.MIME)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DoAR")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("không tạo được file")
            contentResolver.openOutputStream(uri)?.use { Xlsx.write(it, recs) }

            AlertDialog.Builder(this)
                .setTitle("Đã xuất Excel")
                .setMessage("File lưu tại: Download/DoAR/$name\n\nGửi file qua Zalo, email…?")
                .setPositiveButton("Chia sẻ") { _, _ ->
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = Xlsx.MIME
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(send, "Gửi file Excel"))
                }
                .setNegativeButton("Đóng", null)
                .show()
        } catch (e: Exception) {
            Toast.makeText(this, "Lỗi xuất file: " + e.message, Toast.LENGTH_LONG).show()
        }
    }
}
