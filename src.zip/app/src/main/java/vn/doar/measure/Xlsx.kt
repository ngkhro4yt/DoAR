package vn.doar.measure

import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Ghi file Excel .xlsx tối giản, không cần thư viện ngoài. Cỡ chữ 12, không tô nền. */
object Xlsx {
    const val MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    private const val NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val HDR = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;")

    private fun col(i: Int) = ('A' + i).toString()

    private fun str(ref: String, s: String, style: Int) =
        "<c r=\"$ref\" t=\"inlineStr\" s=\"$style\"><is><t xml:space=\"preserve\">${esc(s)}</t></is></c>"

    private fun numCell(ref: String, v: Double, style: Int) =
        "<c r=\"$ref\" s=\"$style\"><v>${String.format(Locale.US, "%.6f", v)}</v></c>"

    fun write(out: OutputStream, recs: List<Record>) {
        val zip = ZipOutputStream(out)
        fun put(name: String, s: String) {
            zip.putNextEntry(ZipEntry(name))
            zip.write(s.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }

        put(
            "[Content_Types].xml", HDR +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "</Types>"
        )
        put(
            "_rels/.rels", HDR +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"$NS_R/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>"
        )
        put(
            "xl/workbook.xml", HDR +
                "<workbook xmlns=\"$NS\" xmlns:r=\"$NS_R\"><sheets>" +
                "<sheet name=\"So do\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
        )
        put(
            "xl/_rels/workbook.xml.rels", HDR +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"$NS_R/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"$NS_R/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>"
        )
        put("xl/styles.xml", HDR + STYLES)

        // Bảng dữ liệu
        val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
        val sb = StringBuilder(HDR)
        sb.append("<worksheet xmlns=\"$NS\">")
        sb.append("<cols>")
        val widths = intArrayOf(6, 18, 14, 12, 8, 50, 30)
        widths.forEachIndexed { i, w ->
            sb.append("<col min=\"${i + 1}\" max=\"${i + 1}\" width=\"$w\" customWidth=\"1\"/>")
        }
        sb.append("</cols><sheetData>")
        sb.append("<row r=\"1\">").append(str("A1", "BẢNG KẾT QUẢ ĐO HIỆN TRƯỜNG (app Đo AR)", 1)).append("</row>")
        sb.append("<row r=\"2\">")
            .append(str("A2", "Ngày xuất: " + df.format(Date()) + ". Số đo bằng AR chỉ để tham khảo, không dùng nghiệm thu khối lượng.", 0))
            .append("</row>")
        val headers = listOf("STT", "Thời gian", "Loại đo", "Giá trị", "Đơn vị", "Chi tiết", "Ghi chú")
        sb.append("<row r=\"4\">")
        headers.forEachIndexed { i, h -> sb.append(str("${col(i)}4", h, 2)) }
        sb.append("</row>")
        recs.forEachIndexed { idx, r ->
            val row = idx + 5
            sb.append("<row r=\"$row\">")
            sb.append(numCell("A$row", (idx + 1).toDouble(), 5))
            sb.append(str("B$row", df.format(Date(r.time)), 3))
            sb.append(str("C$row", r.type, 3))
            sb.append(numCell("D$row", r.value, 4))
            sb.append(str("E$row", r.unit, 3))
            sb.append(str("F$row", r.detail, 3))
            sb.append(str("G$row", r.note, 3))
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        put("xl/worksheets/sheet1.xml", sb.toString())

        zip.finish()
        zip.flush()
    }

    private const val B = "<left style=\"thin\"><color auto=\"1\"/></left><right style=\"thin\"><color auto=\"1\"/></right>" +
        "<top style=\"thin\"><color auto=\"1\"/></top><bottom style=\"thin\"><color auto=\"1\"/></bottom><diagonal/>"

    private const val STYLES =
        "<styleSheet xmlns=\"$NS\">" +
            "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.000\"/></numFmts>" +
            "<fonts count=\"2\">" +
            "<font><sz val=\"12\"/><name val=\"Times New Roman\"/></font>" +
            "<font><b/><sz val=\"12\"/><name val=\"Times New Roman\"/></font>" +
            "</fonts>" +
            "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
            "<borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border><border>$B</border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"6\">" +
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>" +
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\" applyAlignment=\"1\"><alignment vertical=\"center\" wrapText=\"1\"/></xf>" +
            "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment vertical=\"center\"/></xf>" +
            "<xf numFmtId=\"1\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>" +
            "</cellXfs>" +
            "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
            "</styleSheet>"
}
