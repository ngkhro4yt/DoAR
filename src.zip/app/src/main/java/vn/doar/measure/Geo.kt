package vn.doar.measure

import com.google.ar.core.Anchor
import com.google.ar.core.Pose
import com.google.ar.core.TrackingState
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

enum class Mode(val title: String) {
    DISTANCE("Khoảng cách"),
    POLYLINE("Nhiều đoạn"),
    AREA("Diện tích"),
    HEIGHT("Chiều cao")
}

enum class LenUnit(val label: String) {
    MM("mm"), CM("cm"), M("m");

    fun next(): LenUnit = values()[(ordinal + 1) % values().size]
}

/** Một hình đo đang dựng trên màn hình (chỉ truy cập trên luồng GL). */
class Shape(val mode: Mode) {
    val anchors = ArrayList<Anchor>()
    var finished = false

    fun points(): List<FloatArray> =
        anchors.filter { it.trackingState != TrackingState.STOPPED }.map { it.pose.translation }

    fun detachAll() {
        anchors.forEach { runCatching { it.detach() } }
        anchors.clear()
    }
}

/** Ảnh chụp trạng thái để lớp vẽ đọc (bất biến). */
class ShapeSnap(val mode: Mode, val pts: List<FloatArray>, val finished: Boolean)

class FrameSnap(
    val vp: FloatArray,
    val shapes: List<ShapeSnap>,
    val live: FloatArray?,
    val quality: Int,      // 0: chưa có bề mặt, 1: kém chắc chắn, 2: tốt
    val tracking: Boolean
)

object Geo {
    private val VI = Locale("vi", "VN")

    fun num(v: Double, dec: Int): String = String.format(VI, "%,.${dec}f", v)

    fun dist(a: FloatArray, b: FloatArray): Double {
        val dx = (a[0] - b[0]).toDouble()
        val dy = (a[1] - b[1]).toDouble()
        val dz = (a[2] - b[2]).toDouble()
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    fun segments(pts: List<FloatArray>, closed: Boolean): List<Double> {
        val out = ArrayList<Double>()
        for (i in 0 until pts.size - 1) out.add(dist(pts[i], pts[i + 1]))
        if (closed && pts.size >= 3) out.add(dist(pts.last(), pts.first()))
        return out
    }

    fun polyLen(pts: List<FloatArray>): Double = segments(pts, false).sum()

    /** Diện tích đa giác 3D bằng phương pháp Newell (không cần nằm trên mặt phẳng trục). */
    fun area(pts: List<FloatArray>): Double {
        if (pts.size < 3) return 0.0
        var nx = 0.0
        var ny = 0.0
        var nz = 0.0
        for (i in pts.indices) {
            val a = pts[i]
            val b = pts[(i + 1) % pts.size]
            nx += (a[1] - b[1]).toDouble() * (a[2] + b[2]).toDouble()
            ny += (a[2] - b[2]).toDouble() * (a[0] + b[0]).toDouble()
            nz += (a[0] - b[0]).toDouble() * (a[1] + b[1]).toDouble()
        }
        return 0.5 * sqrt(nx * nx + ny * ny + nz * nz)
    }

    fun fmtLen(m: Double, unit: LenUnit): String = when (unit) {
        LenUnit.MM -> num(m * 1000.0, 0) + " mm"
        LenUnit.CM -> num(m * 100.0, 1) + " cm"
        LenUnit.M -> num(m, 3) + " m"
    }

    fun fmtArea(m2: Double): String = num(m2, 2) + " m²"

    fun fmtRecord(r: Record, unit: LenUnit): String =
        if (r.unit == "m²") fmtArea(r.value) else fmtLen(r.value, unit)

    /**
     * Điểm trên đường thẳng đứng đi qua [base] gần tia ngắm giữa màn hình nhất.
     * Trục Y của ARCore luôn hướng lên (ngược trọng lực).
     */
    fun verticalPoint(base: FloatArray, camPose: Pose): FloatArray? {
        val o = camPose.translation
        val z = camPose.zAxis
        val d = doubleArrayOf(-z[0].toDouble(), -z[1].toDouble(), -z[2].toDouble())
        val w0 = doubleArrayOf(
            (base[0] - o[0]).toDouble(),
            (base[1] - o[1]).toDouble(),
            (base[2] - o[2]).toDouble()
        )
        val b = d[1]                                   // u·d, với u = (0,1,0)
        val dd = w0[1]                                 // u·w0
        val e = d[0] * w0[0] + d[1] * w0[1] + d[2] * w0[2]
        val denom = 1.0 - b * b
        if (abs(denom) < 1e-4) return null
        val t = (b * e - dd) / denom
        return floatArrayOf(base[0], (base[1] + t).toFloat(), base[2])
    }
}
