package vn.doar.measure

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Thước thủy (chức năng 5): dựng đứng đo độ nghiêng cạnh; đặt nằm đo nghiêng 2 phương. */
class LevelActivity : Activity(), SensorEventListener {
    private lateinit var sm: SensorManager
    private var sensor: Sensor? = null
    private lateinit var lv: LevelView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        lv = LevelView(this)
        setContentView(lv)
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        lv.setOnLongClickListener {
            lv.calibrate()
            Toast.makeText(this, "Đã hiệu chỉnh vị trí hiện tại = 0°", Toast.LENGTH_SHORT).show()
            true
        }
        lv.setOnClickListener {
            lv.resetCalibration()
            Toast.makeText(this, "Đã bỏ hiệu chỉnh", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        sensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        lv.update(e.values[0], e.values[1], e.values[2])
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

class LevelView(ctx: Context) : View(ctx) {
    private var gx = 0f
    private var gy = 9.81f
    private var gz = 0f
    private var offUpright = 0.0
    private var offX = 0.0
    private var offY = 0.0

    private val d = resources.displayMetrics.density
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 72 * d; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.LTGRAY; textSize = 15 * d; textAlign = Paint.Align.CENTER
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2 * d; color = Color.WHITE
    }

    fun update(x: Float, y: Float, z: Float) {
        val k = 0.15f    // lọc thông thấp cho số đọc ổn định
        gx += k * (x - gx)
        gy += k * (y - gy)
        gz += k * (z - gz)
        invalidate()
    }

    private fun deg(r: Double) = Math.toDegrees(r)
    private fun isFlat(): Boolean {
        val g = sqrt((gx * gx + gy * gy + gz * gz).toDouble())
        return g > 0 && abs(gz) / g > 0.9
    }

    private fun uprightRaw(): Double {
        val a = deg(atan2(gx.toDouble(), gy.toDouble()))
        return a - (a / 90.0).roundToInt() * 90.0
    }

    private fun flatRaw(): Pair<Double, Double> {
        val z = abs(gz).toDouble()
        return Pair(deg(atan2(gx.toDouble(), z)), deg(atan2(gy.toDouble(), z)))
    }

    fun calibrate() {
        if (isFlat()) {
            val (x, y) = flatRaw(); offX = x; offY = y
        } else offUpright = uprightRaw()
    }

    fun resetCalibration() {
        offUpright = 0.0; offX = 0.0; offY = 0.0
    }

    private fun f1(v: Double) = String.format(java.util.Locale("vi", "VN"), "%.1f°", v)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2

        if (isFlat()) {
            val (rx, ry) = flatRaw()
            val ax = rx - offX
            val ay = ry - offY
            val tilt = sqrt(ax * ax + ay * ay)
            val ok = tilt < 0.5
            c.drawColor(if (ok) Color.rgb(20, 120, 40) else Color.BLACK)
            val r = min(w, h) * 0.38f
            c.drawCircle(cx, cy, r, stroke)
            c.drawCircle(cx, cy, r * 0.12f, stroke)
            c.drawLine(cx - r, cy, cx + r, cy, stroke)
            c.drawLine(cx, cy - r, cx, cy + r, stroke)
            val k = r / 15f   // 15° chạm mép vòng tròn
            var bx = (ax * k).toFloat()
            var by = (-ay * k).toFloat()
            val len = sqrt(bx * bx + by * by)
            if (len > r) { bx *= r / len; by *= r / len }
            fillP.color = if (ok) Color.WHITE else Color.rgb(255, 214, 10)
            c.drawCircle(cx + bx, cy + by, r * 0.11f, fillP)
            c.drawText(f1(tilt), cx, cy - r - 30 * d, big)
            c.drawText("Ngang: ${f1(ax)}   Dọc: ${f1(ay)}", cx, cy + r + 40 * d, small)
        } else {
            val a = uprightRaw() - offUpright
            val ok = abs(a) < 0.5
            c.drawColor(Color.BLACK)
            c.save()
            c.rotate(a.toFloat(), cx, cy)
            fillP.color = if (ok) Color.rgb(20, 150, 50) else Color.rgb(60, 60, 64)
            c.drawRect(-w, cy, 2 * w, 2 * h, fillP)
            c.restore()
            c.drawLine(cx - 60 * d, cy, cx + 60 * d, cy, stroke)
            c.drawText(f1(abs(a)), cx, cy - 40 * d, big)
            c.drawText("Áp cạnh máy vào bề mặt cần kiểm tra", cx, cy + 90 * d, small)
        }
        c.drawText("Chạm giữ: hiệu chỉnh về 0°   •   Chạm: bỏ hiệu chỉnh", cx, h - 40 * d, small)
        c.drawText("Đặt nằm: đo 2 phương   •   Dựng đứng: đo nghiêng cạnh", cx, h - 64 * d, small)
    }
}
