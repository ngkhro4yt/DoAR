package vn.doar.measure

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.opengl.Matrix
import android.util.AttributeSet
import android.view.View

/** Lớp vẽ 2D phía trên camera: điểm, đường, nhãn số đo, tâm ngắm. */
class OverlayView(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {

    @Volatile var snap: FrameSnap? = null
    @Volatile var unit: LenUnit = LenUnit.CM

    private val d = resources.displayMetrics.density
    private val yellow = Color.rgb(255, 214, 10)

    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x88000000.toInt(); style = Paint.Style.STROKE; strokeWidth = 6 * d; strokeCap = Paint.Cap.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3 * d; strokeCap = Paint.Cap.ROUND
    }
    private val dash = Paint(line).apply {
        color = yellow; pathEffect = DashPathEffect(floatArrayOf(10 * d, 7 * d), 0f)
    }
    private val dashFaint = Paint(dash).apply { alpha = 120 }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val dotRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FFD60A; style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 15 * d; isFakeBoldText = true; textAlign = Paint.Align.CENTER
    }
    private val bigText = Paint(text).apply { textSize = 20 * d }
    private val labelBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC000000.toInt() }
    private val reticle = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val snapRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 3 * d
    }

    private val rect = RectF()
    private val vIn = FloatArray(4)
    private val vOut = FloatArray(4)

    private fun proj(vp: FloatArray, p: FloatArray): PointF? {
        vIn[0] = p[0]; vIn[1] = p[1]; vIn[2] = p[2]; vIn[3] = 1f
        Matrix.multiplyMV(vOut, 0, vp, 0, vIn, 0)
        if (vOut[3] <= 0.01f) return null
        val x = (vOut[0] / vOut[3] + 1f) * 0.5f * width
        val y = (1f - vOut[1] / vOut[3]) * 0.5f * height
        return PointF(x, y)
    }

    override fun onDraw(c: Canvas) {
        val s = snap ?: return
        if (s.tracking) {
            for (sh in s.shapes) drawShape(c, s, sh)
            drawLive(c, s)
        }
        drawReticle(c, s)
    }

    private fun seg(c: Canvas, a: PointF, b: PointF, p: Paint) {
        c.drawLine(a.x, a.y, b.x, b.y, shadow)
        c.drawLine(a.x, a.y, b.x, b.y, p)
    }

    private fun point(c: Canvas, p: PointF) {
        c.drawCircle(p.x, p.y, 6 * d, dot)
        c.drawCircle(p.x, p.y, 6 * d, dotRing)
    }

    private fun label(c: Canvas, x: Float, y: Float, s: String, big: Boolean = false) {
        val tp = if (big) bigText else text
        val w = tp.measureText(s)
        val fm = tp.fontMetrics
        val h = fm.descent - fm.ascent
        val pad = 7 * d
        rect.set(x - w / 2 - pad, y - h / 2 - pad / 2, x + w / 2 + pad, y + h / 2 + pad / 2)
        c.drawRoundRect(rect, 9 * d, 9 * d, labelBg)
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2, tp)
    }

    private fun drawShape(c: Canvas, s: FrameSnap, sh: ShapeSnap) {
        val n = sh.pts.size
        if (n == 0) return
        val pp = sh.pts.map { proj(s.vp, it) }
        val closed = sh.mode == Mode.AREA && sh.finished && n >= 3

        if (closed && pp.all { it != null }) {
            val path = Path()
            pp.forEachIndexed { i, p -> if (i == 0) path.moveTo(p!!.x, p.y) else path.lineTo(p!!.x, p.y) }
            path.close()
            c.drawPath(path, fill)
        }

        val segCount = if (closed) n else n - 1
        for (i in 0 until segCount) {
            val j = (i + 1) % n
            val a = pp[i]
            val b = pp[j]
            if (a != null && b != null) {
                seg(c, a, b, line)
                val len = Geo.dist(sh.pts[i], sh.pts[j])
                val prefix = if (sh.mode == Mode.HEIGHT) "↕ " else ""
                label(c, (a.x + b.x) / 2, (a.y + b.y) / 2, prefix + Geo.fmtLen(len, unit))
            }
        }
        pp.forEach { if (it != null) point(c, it) }

        if (closed) {
            val vis = pp.filterNotNull()
            if (vis.isNotEmpty()) {
                val cx = vis.map { it.x }.average().toFloat()
                val cy = vis.map { it.y }.average().toFloat()
                label(c, cx, cy, "S = " + Geo.fmtArea(Geo.area(sh.pts)), big = true)
            }
        }
        if (sh.mode == Mode.POLYLINE && sh.finished && n > 2) {
            val last = pp.last()
            if (last != null) label(c, last.x, last.y - 36 * d, "Tổng: " + Geo.fmtLen(Geo.polyLen(sh.pts), unit), big = true)
        }
    }

    private fun drawLive(c: Canvas, s: FrameSnap) {
        val cur = s.shapes.lastOrNull { !it.finished } ?: return
        val live = s.live ?: return
        val lp = proj(s.vp, live) ?: return
        c.drawCircle(lp.x, lp.y, 4 * d, dot)
        if (cur.pts.isEmpty()) return

        val last = cur.pts.last()
        val pl = proj(s.vp, last) ?: return
        seg(c, pl, lp, dash)
        val len = Geo.dist(last, live)
        val prefix = if (cur.mode == Mode.HEIGHT) "↕ " else ""
        label(c, (pl.x + lp.x) / 2, (pl.y + lp.y) / 2, prefix + Geo.fmtLen(len, unit), big = true)

        val cx = width / 2f
        val cy = height / 2f
        if (cur.mode == Mode.AREA && cur.pts.size >= 2) {
            val first = cur.pts.first()
            val pf = proj(s.vp, first)
            if (pf != null) {
                c.drawLine(lp.x, lp.y, pf.x, pf.y, dashFaint)
                if (cur.pts.size >= 3 && Geo.dist(first, live) < MainActivity.SNAP_M) {
                    c.drawCircle(pf.x, pf.y, 14 * d, snapRing)
                }
            }
            label(c, cx, cy + 60 * d, "S ≈ " + Geo.fmtArea(Geo.area(cur.pts + listOf(live))))
        }
        if (cur.mode == Mode.POLYLINE && cur.pts.size >= 2) {
            label(c, cx, cy + 60 * d, "Tổng ≈ " + Geo.fmtLen(Geo.polyLen(cur.pts + listOf(live)), unit))
        }
    }

    private fun drawReticle(c: Canvas, s: FrameSnap) {
        val cx = width / 2f
        val cy = height / 2f
        reticle.color = when {
            !s.tracking -> Color.GRAY
            s.quality >= 2 -> Color.GREEN
            s.quality == 1 -> yellow
            else -> Color.RED
        }
        c.drawCircle(cx, cy, 20 * d, reticle)
        c.drawLine(cx - 6 * d, cy, cx + 6 * d, cy, reticle)
        c.drawLine(cx, cy - 6 * d, cx, cy + 6 * d, reticle)
    }
}
