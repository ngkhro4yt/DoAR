package vn.doar.measure

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Surface
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Camera
import com.google.ar.core.Config
import com.google.ar.core.DepthPoint
import com.google.ar.core.Frame
import com.google.ar.core.Plane
import com.google.ar.core.Point
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.Trackable
import com.google.ar.core.TrackingFailureReason
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableApkTooOldException
import com.google.ar.core.exceptions.UnavailableArcoreNotInstalledException
import com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException
import com.google.ar.core.exceptions.UnavailableSdkTooOldException
import com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class MainActivity : Activity(), GLSurfaceView.Renderer {

    companion object {
        const val SNAP_M = 0.03   // quay về gần điểm đầu ≤ 3 cm thì tự khép kín
    }

    private lateinit var surface: GLSurfaceView
    private lateinit var overlay: OverlayView
    private lateinit var txtStatus: TextView
    private lateinit var btnUnit: Button
    private lateinit var modeTabs: Map<Mode, TextView>

    private var session: Session? = null
    private var installRequested = false
    private val bg = BackgroundRenderer()
    private var textureSet = false
    private var viewW = 1
    private var viewH = 1

    // ---- Trạng thái chỉ dùng trên luồng GL ----
    private val shapes = ArrayList<Shape>()
    private var current = Shape(Mode.DISTANCE)
    private var lastLive: FloatArray? = null
    private var lastTrackable: Trackable? = null
    private var captureRequested = false
    private var lastStatus = ""
    private val viewM = FloatArray(16)
    private val projM = FloatArray(16)
    private val vpM = FloatArray(16)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        surface = findViewById(R.id.surface)
        overlay = findViewById(R.id.overlay)
        txtStatus = findViewById(R.id.txtStatus)
        btnUnit = findViewById(R.id.btnUnit)

        surface.preserveEGLContextOnPause = true
        surface.setEGLContextClientVersion(2)
        surface.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        surface.setRenderer(this)
        surface.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        modeTabs = mapOf(
            Mode.DISTANCE to findViewById<TextView>(R.id.tabDistance),
            Mode.POLYLINE to findViewById<TextView>(R.id.tabPolyline),
            Mode.AREA to findViewById<TextView>(R.id.tabArea),
            Mode.HEIGHT to findViewById<TextView>(R.id.tabHeight)
        )
        modeTabs.forEach { (m, v) -> v.setOnClickListener { selectMode(m) } }
        highlightTab(Mode.DISTANCE)

        overlay.unit = Store.unit(this)
        btnUnit.text = "Đơn vị: " + overlay.unit.label
        btnUnit.setOnClickListener {
            val u = overlay.unit.next()
            overlay.unit = u
            Store.setUnit(this, u)
            btnUnit.text = "Đơn vị: " + u.label
        }

        findViewById<Button>(R.id.btnAdd).setOnClickListener { surface.queueEvent { addPoint() } }
        findViewById<Button>(R.id.btnDone).setOnClickListener { surface.queueEvent { finishCurrent(true) } }
        findViewById<Button>(R.id.btnUndo).setOnClickListener { surface.queueEvent { undo() } }
        findViewById<Button>(R.id.btnClear).setOnClickListener { surface.queueEvent { clearAll() } }
        findViewById<Button>(R.id.btnShot).setOnClickListener { surface.queueEvent { captureRequested = true } }
        findViewById<Button>(R.id.btnLevel).setOnClickListener {
            startActivity(Intent(this, LevelActivity::class.java))
        }
        findViewById<Button>(R.id.btnList).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    // ================= Vòng đời / ARCore =================

    override fun onResume() {
        super.onResume()
        overlay.unit = Store.unit(this)
        btnUnit.text = "Đơn vị: " + overlay.unit.label

        if (session == null) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
                return
            }
            var msg: String? = null
            try {
                when (ArCoreApk.getInstance().requestInstall(this, !installRequested)) {
                    ArCoreApk.InstallStatus.INSTALL_REQUESTED -> {
                        installRequested = true
                        return
                    }
                    ArCoreApk.InstallStatus.INSTALLED -> {}
                    else -> {}
                }
                val s = Session(this)
                val cfg = Config(s)
                cfg.focusMode = Config.FocusMode.AUTO
                cfg.planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
                cfg.lightEstimationMode = Config.LightEstimationMode.DISABLED
                cfg.depthMode = if (s.isDepthModeSupported(Config.DepthMode.AUTOMATIC))
                    Config.DepthMode.AUTOMATIC else Config.DepthMode.DISABLED
                s.configure(cfg)
                session = s
            } catch (e: UnavailableArcoreNotInstalledException) {
                msg = "Cần cài “Google Play Services for AR” từ CH Play"
            } catch (e: UnavailableUserDeclinedInstallationException) {
                msg = "Cần cài “Google Play Services for AR” từ CH Play"
            } catch (e: UnavailableApkTooOldException) {
                msg = "Hãy cập nhật “Google Play Services for AR” trên CH Play"
            } catch (e: UnavailableSdkTooOldException) {
                msg = "Ứng dụng cần cập nhật phiên bản mới"
            } catch (e: UnavailableDeviceNotCompatibleException) {
                msg = "Máy này không hỗ trợ ARCore"
            } catch (e: Exception) {
                msg = "Không khởi tạo được AR: " + e.message
            }
            if (msg != null) {
                txtStatus.text = msg
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                return
            }
        }

        try {
            session?.resume()
        } catch (e: CameraNotAvailableException) {
            txtStatus.text = "Không mở được camera. Hãy đóng app khác đang dùng camera."
            session = null
            return
        }
        surface.onResume()
    }

    override fun onPause() {
        super.onPause()
        if (session != null) {
            surface.onPause()
            session?.pause()
        }
    }

    override fun onDestroy() {
        session?.close()
        session = null
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "App cần quyền Camera để đo", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    // ================= Renderer (luồng GL) =================

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        bg.createOnGlThread()
        textureSet = false
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewW = width
        viewH = height
        GLES20.glViewport(0, 0, width, height)
        session?.setDisplayGeometry(Surface.ROTATION_0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val s = session ?: return
        if (!textureSet) {
            s.setCameraTextureName(bg.textureId)
            s.setDisplayGeometry(Surface.ROTATION_0, viewW, viewH)
            textureSet = true
        }
        val frame: Frame = try {
            s.update()
        } catch (e: Exception) {
            return
        }
        val cam = frame.camera
        bg.draw(frame)

        val tracking = cam.trackingState == TrackingState.TRACKING
        var live: FloatArray? = null
        var quality = 0
        if (tracking) {
            cam.getProjectionMatrix(projM, 0, 0.05f, 100f)
            cam.getViewMatrix(viewM, 0)
            Matrix.multiplyMM(vpM, 0, projM, 0, viewM, 0)

            if (current.mode == Mode.HEIGHT && current.anchors.size == 1) {
                val base = current.anchors[0].pose.translation
                live = Geo.verticalPoint(base, cam.pose)
                quality = if (live != null) 2 else 0
                lastTrackable = null
            } else {
                val hit = bestHit(frame, viewW / 2f, viewH / 2f)
                if (hit != null) {
                    live = hit.first
                    lastTrackable = hit.second
                    quality = hit.third
                } else {
                    lastTrackable = null
                }
            }
        }
        lastLive = live

        val snaps = ArrayList<ShapeSnap>()
        for (sh in shapes) snaps.add(ShapeSnap(sh.mode, sh.points(), true))
        snaps.add(ShapeSnap(current.mode, current.points(), false))
        overlay.snap = FrameSnap(vpM.clone(), snaps, live, quality, tracking)
        overlay.postInvalidate()

        updateStatus(cam, tracking, live, quality)

        if (captureRequested) {
            captureRequested = false
            capture()
        }
    }

    /** Chọn kết quả tốt nhất tại tâm ngắm: mặt phẳng > điểm chiều sâu > điểm đặc trưng. */
    private fun bestHit(frame: Frame, x: Float, y: Float): Triple<FloatArray, Trackable, Int>? {
        var depth: Triple<FloatArray, Trackable, Int>? = null
        var feature: Triple<FloatArray, Trackable, Int>? = null
        for (hit in frame.hitTest(x, y)) {
            val tr = hit.trackable
            if (tr is Plane && tr.trackingState == TrackingState.TRACKING && tr.isPoseInPolygon(hit.hitPose)) {
                return Triple(hit.hitPose.translation, tr, 2)
            }
            if (tr is DepthPoint && depth == null) {
                depth = Triple(hit.hitPose.translation, tr, 2)
            }
            if (tr is Point && feature == null &&
                tr.orientationMode == Point.OrientationMode.ESTIMATED_SURFACE_NORMAL
            ) {
                feature = Triple(hit.hitPose.translation, tr, 1)
            }
        }
        return depth ?: feature
    }

    private fun updateStatus(cam: Camera, tracking: Boolean, live: FloatArray?, quality: Int) {
        val n = current.anchors.size
        val msg = when {
            !tracking -> when (cam.trackingFailureReason) {
                TrackingFailureReason.INSUFFICIENT_LIGHT -> "Thiếu sáng, hãy bật đèn hoặc ra chỗ sáng hơn"
                TrackingFailureReason.EXCESSIVE_MOTION -> "Di chuyển máy chậm lại"
                TrackingFailureReason.INSUFFICIENT_FEATURES -> "Hướng camera vào bề mặt có chi tiết, hoa văn"
                TrackingFailureReason.CAMERA_UNAVAILABLE -> "Camera đang bận"
                else -> "Lia máy chậm sang hai bên để khởi tạo…"
            }
            live == null -> "Lia máy để tìm bề mặt"
            quality == 1 -> "Bề mặt chưa chắc chắn, số đo có thể kém chính xác"
            else -> when (current.mode) {
                Mode.DISTANCE -> if (n == 0) "Ngắm điểm đầu, bấm +" else "Ngắm điểm cuối, bấm +"
                Mode.POLYLINE -> if (n < 2) "Bấm + để thêm điểm" else "Bấm + để thêm điểm, bấm Xong để kết thúc"
                Mode.AREA -> if (n < 3) "Ngắm từng góc, bấm +" else "Quay về điểm đầu hoặc bấm Xong để khép kín"
                Mode.HEIGHT -> if (n == 0) "Ngắm chân đối tượng trên sàn, bấm +" else "Nâng máy ngắm đỉnh đối tượng, bấm +"
            }
        }
        if (msg != lastStatus) {
            lastStatus = msg
            runOnUiThread { txtStatus.text = msg }
        }
    }

    // ================= Thao tác đo (luồng GL) =================

    private fun addPoint() {
        val s = session ?: return
        val p = lastLive ?: run {
            toast("Chưa xác định được bề mặt tại tâm ngắm")
            return
        }
        val pts = current.points()
        if (current.mode == Mode.AREA && pts.size >= 3 && Geo.dist(p, pts.first()) < SNAP_M) {
            finishCurrent(true)
            return
        }
        val pose = Pose.makeTranslation(p[0], p[1], p[2])
        val anchor = try {
            lastTrackable?.createAnchor(pose) ?: s.createAnchor(pose)
        } catch (e: Exception) {
            try {
                s.createAnchor(pose)
            } catch (e2: Exception) {
                toast("Không đặt được điểm, thử lại")
                return
            }
        }
        current.anchors.add(anchor)
        if ((current.mode == Mode.DISTANCE || current.mode == Mode.HEIGHT) && current.anchors.size == 2) {
            finishCurrent(false)
        }
    }

    private fun finishCurrent(manual: Boolean) {
        val pts = current.points()
        val m = current.mode
        val now = System.currentTimeMillis()
        val rec: Record = when (m) {
            Mode.DISTANCE, Mode.HEIGHT -> {
                if (pts.size < 2) {
                    if (manual) toast("Cần 2 điểm")
                    return
                }
                Record(now, m.title, Geo.dist(pts[0], pts[1]), "m", "")
            }
            Mode.POLYLINE -> {
                if (pts.size < 2) {
                    toast("Cần ít nhất 2 điểm")
                    return
                }
                val segs = Geo.segments(pts, false)
                Record(
                    now, m.title, segs.sum(), "m",
                    "Số đoạn: ${segs.size}; các đoạn (m): " + segs.joinToString("; ") { Geo.num(it, 3) }
                )
            }
            Mode.AREA -> {
                if (pts.size < 3) {
                    toast("Cần ít nhất 3 điểm để tính diện tích")
                    return
                }
                val segs = Geo.segments(pts, true)
                Record(
                    now, m.title, Geo.area(pts), "m²",
                    "Chu vi: ${Geo.num(segs.sum(), 3)} m; số đỉnh: ${pts.size}; các cạnh (m): " +
                        segs.joinToString("; ") { Geo.num(it, 3) }
                )
            }
        }
        current.finished = true
        shapes.add(current)
        current = Shape(m)
        val shown = Geo.fmtRecord(rec, overlay.unit)
        runOnUiThread {
            Store.add(this, rec)
            Toast.makeText(this, "Đã lưu: ${rec.type} = $shown", Toast.LENGTH_SHORT).show()
        }
    }

    private fun undo() {
        if (current.anchors.isNotEmpty()) {
            val a = current.anchors.removeAt(current.anchors.size - 1)
            runCatching { a.detach() }
        } else if (shapes.isNotEmpty()) {
            shapes.removeAt(shapes.size - 1).detachAll()
        }
    }

    private fun clearAll() {
        shapes.forEach { it.detachAll() }
        shapes.clear()
        current.detachAll()
    }

    private fun setModeOnGl(m: Mode) {
        if (current.mode == m) return
        current.detachAll()
        current = Shape(m)
    }

    private fun selectMode(m: Mode) {
        highlightTab(m)
        surface.queueEvent { setModeOnGl(m) }
    }

    private fun highlightTab(m: Mode) {
        modeTabs.forEach { (k, v) ->
            if (k == m) {
                v.setBackgroundResource(R.drawable.bg_tab_sel)
                v.setTextColor(Color.BLACK)
            } else {
                v.setBackgroundResource(R.drawable.bg_tab)
                v.setTextColor(Color.WHITE)
            }
        }
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    // ================= Chụp màn hình (chức năng 6) =================

    private fun capture() {
        val w = viewW
        val h = viewH
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
        buf.rewind()
        val raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(buf)

        runOnUiThread {
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            c.save()
            c.scale(1f, -1f, w / 2f, h / 2f)   // ảnh OpenGL bị lộn ngược
            c.drawBitmap(raw, 0f, 0f, null)
            c.restore()
            overlay.draw(c)

            val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(Date())
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 14 * resources.displayMetrics.density
                setShadowLayer(4f, 0f, 0f, Color.BLACK)
            }
            c.drawText("Đo AR  •  $stamp", 16f * resources.displayMetrics.density, h - 20f * resources.displayMetrics.density, p)
            saveImage(out)
            raw.recycle()
        }
    }

    private fun saveImage(bmp: Bitmap) {
        try {
            val name = "DoAR_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DoAR")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("không tạo được file")
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            Toast.makeText(this, "Đã lưu ảnh vào Thư viện › Pictures/DoAR", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Lỗi lưu ảnh: " + e.message, Toast.LENGTH_LONG).show()
        }
    }
}
